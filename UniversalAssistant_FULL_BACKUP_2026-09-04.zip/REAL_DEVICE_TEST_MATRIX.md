# Real Device Test Matrix

| Capability | Why device is required | Status |
|---|---|---|
| Microphone and speech | Physical audio route, permission sheets, accents | DEVICE_TEST_REQUIRED — Test VOICE-001 queued |
| App Intent / Action Button route | System surfaces and device configuration | DEVICE_TEST_REQUIRED — Test VOICE-002 queued |
| Contacts | Real full/limited permission, exact-ID alias and ambiguous-name resolution | DEVICE_TEST_REQUIRED — CONTACTS-001 |
| Calendar | Full-access permission and real create/read/update/delete/undo | DEVICE_TEST_REQUIRED — CALENDAR-001 |
| Reminders | Full-access permission and real create/read/update/delete/undo | DEVICE_TEST_REQUIRED — REMINDERS-001 |
| Audio recorder | Permission, start/pause/resume/stop/play/rename/delete/share, interruptions and routes | DEVICE_TEST_REQUIRED — RECORDER-001 |
| GPS and navigation handoff | Physical sensors and installed apps | NOT_TESTED — M3 |
| Accurate location | When-in-use permission, reduced/full accuracy, stale/poor recovery and physical movement | DEVICE_TEST_REQUIRED — LOCATION-001 |
| Places | Live regional MapKit queries, place IDs, addresses, categories and ranking | LIVE_TEST_REQUIRED — PLACES-001 |
| Route/navigation | Live MapKit routes, actual detour and Apple/Google/Waze exact handoff | LIVE_DEVICE_TEST_REQUIRED — NAVIGATION-001 |
| WeatherKit | Live current/hourly/daily response, entitlement, attribution and destination context | LIVE_DEVICE_TEST_REQUIRED — WEATHER-001 |
| Location recovery | Poor/suspicious resampling, denied permission Settings route and explicit manual fallback | DEVICE_TEST_REQUIRED — LOCATION-002 |
| Ride handoff | Provider app/web behavior, exact pickup/dropoff preservation and owner-issued Uber client ID | LIVE_DEVICE_TEST_REQUIRED — RIDE-001 |
| Public transport | Regional scheduled versus real-time attribution and exact route handoff | LIVE_DEVICE_TEST_REQUIRED — TRANSPORT-001 |
| Ticket handoff | Exact itinerary/fare/inventory preservation and confirmation before leaving the app | LIVE_DEVICE_TEST_REQUIRED — TICKET-001 |
| Installed app actions | Actual schemes, Universal Links, App Intents/App Shortcuts and absent-app fallback | DEVICE_TEST_REQUIRED — DEVICE-APP-001 |
| Photos local search | Full/limited/denied permission plus controlled date/location/album assets and exact open | DEVICE_TEST_REQUIRED — LOCAL-PHOTO-001 |
| Files local search | Document picker/provider, security-scoped lifetime, controlled filename result and exact open | DEVICE_TEST_REQUIRED — LOCAL-FILE-001 |
| Core Spotlight | Assistant-owned item indexing/removal and system search visibility; no foreign-index claim | DEVICE_TEST_REQUIRED — LOCAL-SPOTLIGHT-001 |
| Local search offline/latency | Contacts/Calendar/Reminders/Photos/Files search offline and realistic latency measurement | DEVICE_TEST_REQUIRED — LOCAL-SEARCH-PERF-001 |
| Gmail connected account | OAuth grant plus controlled real search/raw/attachment/draft/send/label round trip and revocation | LIVE_DEVICE_TEST_REQUIRED — queue MS-927-940-LIVE-GMAIL |
| Messages and messengers | System composer plus installed WhatsApp/Telegram/Viber/Signal supported handoff and absent-app paths | DEVICE_TEST_REQUIRED — queue MS-941-948-LIVE-MESSAGING |
| Camera / Music / Podcasts | Physical capture, MusicKit account playback and regional podcast catalog/handoff | LIVE_DEVICE_TEST_REQUIRED — queue MS-949-955-LIVE-APPLE-SYSTEM-DOMAINS |
| Universal Personal Search | One query over controlled authorized sources, exact-source disclosure/open and partial failure | DEVICE_TEST_REQUIRED — source-specific M12 queue items |
| CarPlay | Exact approved category/template in a supported CarPlay environment | DEVICE_TEST_REQUIRED — queue MS-977-979-LIVE-CARPLAY |
