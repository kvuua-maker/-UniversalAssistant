# Canonical Specification Source

The project source of truth is the complete, indivisible combination of:

1. `docs/UniversalAssistant_FULL_UNABRIDGED_MASTER_SPEC_v13.2_MAC_GIT_VERIFIED_FINAL.txt`
   - SHA-256: `16489fc577d199918fedb99f68e5fb59548361f4e15f1253cf3c9e7f2bd8fd95`
   - 7,315 lines / 328,666 bytes
2. `docs/UniversalAssistant_v13.2_MARKETPLACE_COMMERCE_AFFILIATE_FINAL_ADDENDUM.txt`
   - SHA-256: `299bf8025f23a120c77329f831c26217b9ba810835322cf8b085fc09d6c9c23b`
   - 259 lines / 11,837 bytes
3. `docs/DETERMINISTIC_MULTI_STEP_COORDINATION_BOUNDED_AI_FALLBACK_ADDENDUM.md`
   - Owner-supplied canonical additive coordination and bounded-AI contract, accepted 2026-09-02.
   - SHA-256: `7bff9bbd535f1d5e2de52c154d8726552771412ee2160247749e5b739ef9a0ef`
   - 31 lines / 4,278 bytes.
4. `docs/UniversalAssistant_Business_Partner_Platform_FINAL.txt`
   - SHA-256: `9cc1b9eba8641f9858bb3e599a48787f50180d6fc68e76165bcaf70ad17022b7`
   - 277 lines / 14,984 bytes; copied byte-for-byte from the owner-provided attachment on 2026-09-02.
5. `docs/ZERO_OMISSION_REQUIREMENTS_VERIFICATION_EXTERNAL_DEPENDENCY_COMPLETION_POLICY.md`
   - SHA-256: `bb12b460bc75ae32d7404e33fe000b9f1ce7e5af13386c4997ee5430aadf7d21`
   - 381 lines / 12,702 bytes; owner-supplied canonical policy accepted on 2026-09-02.
   - Persistent live-verification state: `LIVE_VERIFICATION_QUEUE.json`.
6. `docs/VOICE_OUTPUT_POLICY_ADDENDUM.md`
   - SHA-256: `1a302401f5d5b15844a85d6721be6260f579c583d5aa61246bb1ce4d3f4ff5ea`
   - 13 lines / 1,104 bytes; owner-supplied canonical voice-output policy accepted on 2026-09-02.
7. `docs/UNIVERSALASSISTANT_FINAL_VISUAL_UI_UX_DESIGN_SYSTEM_ADDENDUM.md`
   - SHA-256: `d69ab80ed56c01a54c7a5bbf64e669cfdc222c1200c4270c2d44a86dc5c8fa28`
   - 59 lines / 9,794 bytes; owner-supplied final visual/UI/UX canon accepted on 2026-09-02.
   - Governs visual-source priority, native presentation, voice orb, themes, accessibility, golden visual flows and physical owner review without changing verified domain behavior.
8. `docs/QUICK_LAUNCH_PHYSICAL_ACCESS_ADDENDUM.md`
   - SHA-256: `c8a6d5392340b61a6716fb5239445faf108ed5eebcdfc414462e135afdff9ba4`
   - 17 lines / 2,182 bytes; owner-supplied canonical quick-launch and physical-access policy accepted on 2026-09-02.
   - Requires device-capability-aware official Apple launch paths into voice listening, permission-only interruption, truthful text fallback and no private button interception.
9. `docs/BUSINESS_PLATFORM_COMPETITIVE_GAP_AUDIT.md`
   - SHA-256: `9e90bffe15f8f008bb71185449df579120b0fe94b89bc2f34ee3f73243dc8e7d`
   - Owner-mandated evidence-first targeted audit accepted on 2026-09-02.
   - Requires minimal partner customer/inbox/catalog/transaction/connector completion by reuse of M9/commerce/appointment infrastructure; explicitly excludes a second CRM, ERP, accounting, POS, warehouse, marketing or AI call-centre platform.
10. `docs/GENERAL_UNKNOWN_INTENT_DISCOVERY_ANSWER_ACTION_ADDENDUM.md`
   - SHA-256: `5f3f4f051ee4758a7e6981c1d33b2d12354fc74987ebcb99b94635070cb266fe`
   - 29 lines / 4,535 bytes; owner-mandated canonical unknown-intent discovery/answer/action policy accepted on 2026-09-03.
   - Requires specialized-capability precedence followed by deterministic generic discovery, bounded AI only for residual ambiguity/synthesis, native verified results, truthful actions, existing safety gates and honest limitation.

11. `docs/UniversalAssistant_Jobs_Marketplace_FINAL_CLEAR_NUMBERED.txt`
   - SHA-256: `4b46941d2c6d6930c328a726e5ee1d3c9d56c178aad9fe596d6913e5e33ca7b7`
   - 296 lines / 20,668 bytes; copied byte-for-byte from the owner attachment on 2026-09-03.
   - Adds 97 independently tracked `JOBS-ID` requirements and preserves OUR JOBS FIRST → active commercial partners → legitimate external fallback only when insufficient.

12. `docs/JOBS_LEGACY_01_95_COVERAGE.md`
   - SHA-256: `2f36df75366e6cd13bbd6f802d70eefb93201c6e92ce95689f300b21a7f2bdc5`
   - Owner-provided inline legacy Jobs sections 1–95 mapped 95/95 to the authoritative numbered Jobs canon on 2026-09-03.
   - Only LEGACY-03 source priority is superseded, strictly by JOBS-007–009; every non-conflicting legacy requirement remains preserved.


13. `docs/UniversalAssistant_Loyalty_Discount_Attribution_Commission_Integrity_FINAL_NUMBERED.txt`
   - SHA-256: `d08375c5fabc74cc493ebb2fd5f6a25cd48a857fb117504ab82240e21e005dc4`
   - 127 independently tracked `LOYALTY-ID` requirements accepted on 2026-09-03.
   - Preserves customer benefit and UA revenue as separate states; partner-specific unknown behavior remains fail-closed and queued for live verification.

14. `docs/UniversalAssistant_Privacy_AI_Data_Flow_Hardening_FINAL_NUMBERED.txt`
   - SHA-256: `2cd2094900eb086a176ba85a84f22555d9ba9d167132b8b5bfb33422dffe10ea`
   - 168 independently tracked `PRIVACY-ID` requirements accepted on 2026-09-03.
   - Requires capability-preserving local-first, purpose-bound, consent-governed minimization and absolute NEVER_AI secret handling.

15. `docs/UniversalAssistant_Universal_Audio_Device_Control_FINAL_NUMBERED.txt`
   - SHA-256: `50b594e3027f9b1f6ed446f9222e534430e33566b8ad3cd2b0d45f13d4708a50`
   - 147 independently tracked `AUDIO-ID` requirements accepted on 2026-09-04.
   - Universal basic control uses only public/official mechanisms; deep control is model-evidenced, DSP is limited to permitted streams, and physical/provider claims remain live-only.

All accepted addenda augment the Master Spec and do not remove or weaken it. Every requirement retains an evidence-backed zero-omission status; documentation, interfaces, mocks and external dependencies alone never establish completion. Later explicit supersession rules inside the Master Spec take precedence over earlier conflicting wording, subject to safety, law, current platform/provider truth, privacy and security.

Both canonical files were read completely and copied byte-for-byte from the owner-provided attachments on 2026-09-01. Their hashes were verified after persistence.

Repository reconciliation found M0–M4 locally accepted and the implemented M5 service, ride, transport and ticket-engine checkpoints frozen. M5 acceptance was premature because requirement 814 also requires travel/hotel flows, authentication boundaries, safe booking/purchase handoff and partial provider degradation. Work resumes with the first missing atomic block: `M5-HOTEL-SEARCH-CORE`.
