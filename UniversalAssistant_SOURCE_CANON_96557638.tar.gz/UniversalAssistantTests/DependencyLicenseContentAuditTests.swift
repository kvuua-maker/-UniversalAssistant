import Foundation
import Testing

@Suite("Dependency, license and content audit")
struct DependencyLicenseContentAuditTests {
    private var root: URL {
        URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
    }

    @Test func productionTargetsHaveNoUninventoriedExternalPackages() throws {
        let package = try String(contentsOf: root.appendingPathComponent("Backend/Package.swift"), encoding: .utf8)
        let project = try String(contentsOf: root.appendingPathComponent("UniversalAssistant.xcodeproj/project.pbxproj"), encoding: .utf8)
        let inventory = try String(contentsOf: root.appendingPathComponent("DEPENDENCIES.md"), encoding: .utf8)

        for (dependency, inventoryName) in [("vapor/vapor.git", "vapor"), ("apple/swift-crypto.git", "swift crypto"), ("iansampson/AppAttest.git", "appattest")] {
            #expect(package.contains(dependency))
            #expect(inventory.lowercased().contains(inventoryName), "Dependency missing from inventory: \(dependency)")
        }
        #expect(!project.contains("XCRemoteSwiftPackageReference"))
        #expect(!project.contains("XCSwiftPackageProductDependency"))
        #expect(inventory.contains("reproducibly pinned"))
        #expect(inventory.contains("Version/source"))
        #expect(inventory.contains("Privacy implications"))
    }

    @Test func repositoryBundlesNoUnlicensedMediaCatalog() throws {
        let product = root.appendingPathComponent("UniversalAssistant")
        let mediaExtensions = Set(["png", "jpg", "jpeg", "gif", "webp", "mp3", "wav", "mp4"])
        let files = FileManager.default.enumerator(at: product, includingPropertiesForKeys: nil)?
            .compactMap { $0 as? URL } ?? []
        let inventory = try String(contentsOf: root.appendingPathComponent("DEPENDENCIES.md"), encoding: .utf8)
        let bundledMedia = files
            .filter { mediaExtensions.contains($0.pathExtension.lowercased()) }
            .map { $0.path.replacingOccurrences(of: root.path + "/", with: "") }
        #expect(bundledMedia == ["UniversalAssistant/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png"])
        #expect(inventory.contains("b2ca19316a2ad5483b96bd4fe63ba97c373fb3d1a964d28d1526cc1f68e8c113"))
        for policy in ["reproducible exact version", "license compatibility", "privacy manifests", "provenance"] {
            #expect(inventory.contains(policy))
        }
    }
}
